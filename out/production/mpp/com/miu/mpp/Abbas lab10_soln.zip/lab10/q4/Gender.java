package com.miu.mpp.lab10.q4;

public enum Gender {
	M, F
}
