package com.miu.mpp.lab10.q4;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
