package com.miu.mpp.lab10.q1.javapackage;


import com.miu.mpp.lab10.q1.bugreporter.BugReport;

@BugReport(assignedTo="Tom Jones", severity=1, reportedBy="Corazza")
public interface ClosedCurve {
	public double computePerimeter();
}
