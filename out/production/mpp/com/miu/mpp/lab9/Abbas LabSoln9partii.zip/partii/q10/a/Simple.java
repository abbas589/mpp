package com.miu.mpp.lab9.partii.q10.a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
