package com.miu.mpp.lab5.prob2;

public class MuteQuack implements QuackBehaviour{

    @Override
    public void quack() {
        System.out.println("cannot quack");
    }
}
