package com.miu.mpp.lab5.lab3;

public interface Shape {
    double computeArea();
}
