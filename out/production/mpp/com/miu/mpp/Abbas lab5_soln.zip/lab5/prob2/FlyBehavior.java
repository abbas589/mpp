package com.miu.mpp.lab5.prob2;

public interface FlyBehavior {
    void fly();
}
