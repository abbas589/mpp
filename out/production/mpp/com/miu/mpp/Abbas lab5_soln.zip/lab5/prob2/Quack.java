package com.miu.mpp.lab5.prob2;

public class Quack implements QuackBehaviour {

    @Override
    public void quack() {
        System.out.println("Quacking");
    }
}
