package com.miu.mpp.lab5.prob2;

public interface QuackBehaviour {
    void quack();
}
