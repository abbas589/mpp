package com.miu.mpp.lab7.q4;

public class MuteQuack implements QuackBehavior {
	public void quack() {
		System.out.println("  cannot quack");
	}
}
