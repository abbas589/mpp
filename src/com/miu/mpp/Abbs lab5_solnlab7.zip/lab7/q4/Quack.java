package com.miu.mpp.lab7.q4;

public class Quack implements QuackBehavior {
	public void quack() {
		System.out.println("  quacking");
	}
}
