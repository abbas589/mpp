package com.miu.mpp.lab7.q4;

public class MallardDuck extends Duck {

	@Override
	public void display() {
		System.out.println("  display");
		
	}

}
