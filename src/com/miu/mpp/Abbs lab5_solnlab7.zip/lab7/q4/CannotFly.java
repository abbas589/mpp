package com.miu.mpp.lab7.q4;

public class CannotFly implements FlyBehavior {
	public void fly() {
		System.out.println("  cannot fly");
	}
}
