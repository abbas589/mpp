package com.miu.mpp.lab7.q4;

public class DecoyDuck extends Duck {

	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
}
