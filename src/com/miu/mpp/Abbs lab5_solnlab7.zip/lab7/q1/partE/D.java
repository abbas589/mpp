package com.miu.mpp.lab7.q1.partE;

/**
 * @author bazz
 * Jan 31 2023
 * 17:06
 */
public interface D extends B, C {
    void method();
}
