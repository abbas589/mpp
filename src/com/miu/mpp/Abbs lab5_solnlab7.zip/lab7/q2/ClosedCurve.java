package com.miu.mpp.lab7.q2;

public interface ClosedCurve {	
	double computePerimeter();

}
