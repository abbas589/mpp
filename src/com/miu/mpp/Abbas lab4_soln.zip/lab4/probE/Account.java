package com.miu.mpp.lab4.probE;

public abstract class Account {
    abstract String getAccountID();

    abstract double getBalance();

    abstract double computeUpdatedBalance();
}
